# Menu Magnet Haptic Profiles v3.0.1

Standalone native macOS Dock app. Reads macOS Accessibility elements beneath the pointer and provides exactly **one trackpad haptic snap** when entering a configured region. Never clicks, drags, synthesizes pointer motion, changes cursor position, highlights UI, or activates elements.

## v3.0.1 crash fix (macOS 27.3)

A supplied macOS crash report identified an `EXC_BREAKPOINT` in Thread 9,
`com.menumagnet.hapticprofiles.ax`. The background worker called
`AXUIElementCopyElementAtPosition`; that call re-entered the app's own
SwiftUI view hit-testing (`NSHostingView.hitTest`) and triggered a
`MainActor.assumeIsolated` executor assertion. The crash happened 1.35 seconds
after launch, before any evidence of a hardware actuator call.

- AX probing now runs on the main thread only, instead of a serial worker.
- Added an explicit off-main guard to the scanner.
- Skip hit-testing of the app's own windows by looking up the owning PID in the
  Core Graphics window list BEFORE entering Accessibility hit-testing.
- Reduce probe frequency to no more than 20 Hz; the cursor still moves natively.
- Keep icon, profiles, haptic patterns, experimental helper, and current bundle ID.
- Installer waits for a brief post-launch smoke check before declaring success.
- This resolves the specific threading error in the crash stack, but cannot be
  fully confirmed without compiling and running on the user's Mac.

## Changes

- Brand-new illustrated multi-size macOS app icon installed as `AppIcon.icns`.
- Removed all 2-tick/3-tick repeat logic (`asyncAfter` / scheduling). Every event triggers at most one feedback request, subject to existing boundary de-bouncing.
- All roles in Default and non-Silent saved profiles reset to **Level 1** ONCE when updating from 2.x. Named profiles, role lists, per-role pattern choices, and active-profile selection are kept. Silent remains Off. Custom strengths can then be set and will persist.
- Strength choices: **Off / Level 1 (soft) / Level 2 (medium) / Level 3 (firm) / Level 4 (hard)**. Save different levels in each named profile; use Apply to all or Set all Off.
- Experimental Enhanced Mode offers distinct **single hardware waveforms** for levels 1–4 (hardware IDs 4, 5, 6, 2). This is not a calibrated or continuous 0–100% intensity multiplier. Actual feel varies across devices and system versions.
- Apple public standard mode always emits **one** chosen built-in pattern. Standard AppKit does not allow intensity control, so all non-Off levels feel identical in Standard mode.
- Enhanced Mode is OFF on every new launch. On manual enable, an isolated helper loads Apple's **undocumented** `MultitouchSupport.framework`. If the helper exits or fails, the main app should continue and fall back to standard haptics. Private framework calls can crash the helper, and compatibility has not been validated on macOS 27.3.
- Live Accessibility inspector, Finder/Dock/scrollbar detection rules and profile management are retained.

## Build / installation

1. Download `MenuMagnetHapticProfiles-v3.0.1.zip` into `~/Downloads`.
2. Extract into a temporary folder and run `MenuMagnetHapticProfiles-v3.0.1/install.sh` using the Terminal command supplied in the conversation.
3. Installer compiles the Swift app and C helper and uses `iconutil` to build the `.icns`, then codesigns and verifies the app **before** uninstalling previous versions.
4. Once compilation succeeds, it quits previous tools, requests targeted old-bundle Accessibility/Input Monitoring resets, uninstalls recognized previous bundles from `~/Applications` and `/Applications`, installs and launches the new version.
5. Same bundle ID as 2.x: `com.menumagnet.hapticprofiles.v2`. No deliberate reset of that current identity. Ad-hoc signing can still cause macOS to require Accessibility reapproval; we cannot promise TCC entries disappear from System Settings.
6. Downloaded ZIP is deleted only after successful install and launch. No app backup retained.

## Testing

- First test with **Enhanced Mode OFF**, especially the Level 1 entry snap.
- Switch Enhanced Mode ON and try `Test` next to a harmless role, selecting Levels 1–4 to compare single snaps. If helper is unavailable, the status should show fallback.
- If macOS reports a helper crash, capture the diagnostic report; v3's private hardware code is isolated, but behavior is not confirmed on your Mac.
- Moving across controls must not alter the pointer, click controls, or change visible screen state.

## Build checks performed here

- Swift source `-frontend -parse` passes in a Linux Swift toolchain (syntax, not macOS type-checking).
- Foundation-only role/profile tests, entry-transition tests pass.
- Script passes `bash -n`, iconset contains 10 standard multi-resolution PNGs, and ZIP verified.
- Cannot perform full macOS SDK compilation or a physical Force Touch hardware test in the current runtime.

## API reference & provenance

Apple AppKit `NSHapticFeedbackManager` (public): https://developer.apple.com/documentation/appkit/nshapticfeedbackmanager

Empirical private actuator reference (public-domain project): https://github.com/MatMercer/mactic

Private function calling conventions (MIT example): https://gist.github.com/niw/b120b460e854ec10cefeeb60784f5dbb
